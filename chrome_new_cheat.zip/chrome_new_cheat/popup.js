document.getElementById('changeCount').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.scripting.executeScript({
            target: { tabId: tabs[0].id },
            func: () => {
                const script = document.createElement('script');
                script.src = chrome.runtime.getURL('injected.js'); // Inject the external file
                document.documentElement.appendChild(script);
                script.remove(); // Clean up after execution
            }
        });
    });
});
 