// Draggable box and buttons HTML 
const containerelement = document.createElement('div');
containerelement.innerHTML = `
<style>
    #draggableCage {
        position: absolute;
        top: 0;
        left: 0;
        width: auto;
        height: auto;
        background-color: white;
        border: 2px solid #333;
        border-radius: 10px;
        cursor: grab;
        user-select: none;
        padding: 0.5vh;
        justify-content: center;
        text-align: center;
        align-items: center;
        flex-direction: column;
        gap: 1vh;
        font-size: 2vh;
    }
    #draggableCage fieldset,#draggableCage dd,#draggableCage section{
        min-inline-size: 0;
        margin: 0;
        border: 0;
        padding: 0;
    }
    #draggableCage:active,
    #draggableCage  > summary > dd:nth-of-type(2),
    #draggableCage  > summary > dd:nth-of-type(2) > span{
        cursor: grabbing;
    }
    #draggableCage  > summary {
        list-style: none;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        box-sizing: border-box;
        width: 100%;
    }
    #draggableCage  > summary > dd:nth-of-type(1){
        display: flex;
        justify-content: center;
        flex-direction: column;
        height: 3vh;
        align-items: center;
        aspect-ratio: 1/1;        /* make it stretch full width */
        box-sizing: border-box;
        margin: 0;
    }
    #draggableCage  > summary > dd:nth-of-type(2),
    #draggableCage  > summary > dd:nth-of-type(2) > span{
        margin: 0;
        justify-content: center;
        text-align: center;
        align-items: center;
        cursor: grab;
        width: 100%;
    }
    #draggableCage  > summary > dd > div {
        flex: none;          /* keep lines same size */
        width: 20px;
        height: 0.5vh;
        margin: 2px;
        background-color: black;
    }
    #draggableCage  > div {
        display: flex;
        flex-direction: column;
        background-color: lightblue;
        min-width: 15vw;
        height: auto;
        border-radius: 0 10px 10px 10px;
        gap: 1vh;
        box-shadow: 0 0px 0px 1px black;
        overflow: hidden;
    }
    #draggableCage  > div > div {
        min-width: 15vw;
        height: 3.5vh;
        padding: 0.5vh;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        background-color: #4caf50;
    }
     #draggableCage  > div > div > input{
        display: none;
     }
    #draggableCage  > div > div > label{
        height: 100%;
        width: 50%;
        display: flex;
        margin-bottom: 0 !important;
        align-items: center;
        justify-content: center;
        text-align: center;
        color: gray;
         
    }
    #automatic_detec_setup:checked ~ label[for="automatic_detec_setup"], #manual_detec_setup:checked ~ label[for="manual_detec_setup"] {
        background: green;
        color: white;
        box-shadow: 0 0 10px 2px white;
        font-weight: bold;
    }
    label[for="automatic_detec_setup"]{
        border-radius: 10px 0 0 10px;
    }
    label[for="manual_detec_setup"]{
        border-radius: 0 10px 10px 0;
    }
    #dahsboard_automatic_only_lol,#dahsboard_manual_only_lol{display: none;}
    div:has(#automatic_detec_setup:checked) > #dahsboard_automatic_only_lol ,
    div:has(#manual_detec_setup:checked) > #dahsboard_manual_only_lol {
        display: flex;
        flex-direction: column;
    }
    #dahsboard_manual_only_lol > section{
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        padding: 0 0.5vh 0.5vh 0.5vh;
        gap: 0.2vh;
    }
    #dahsboard_manual_only_lol > section > dd{
        border: 1px solid #333;
        border-radius: 5px;
    }
    #dahsboard_manual_only_lol > section > dd:nth-of-type(1){
        flex-grow: 1;
        text-align: start;
    }
    #dahsboard_manual_only_lol > section > dd:nth-of-type(2),
    #dahsboard_manual_only_lol > section > dd:nth-of-type(3){
        width: 20%;
        cursor: pointer;
    }
        #warning_detection_1rst span {
        animation: pop1Loop 1s infinite; 
        transform-origin: center;
    }
        @keyframes pop1Loop {
        0%,50%, 100% {
        transform: scale(0);          /* normal size */
    }
    25%,75% {
        transform: scale(1);        /* pop bigger */
    }
    }
  </style>

    <details id="draggableCage" style="z-index: 1; top: 250px; left: 750px; display: flex;">
        <summary>
            <dd>
                <div></div>
                <div></div>
                <div></div>
            </dd>
            <dd id="warning_detection_1rst" style="display: none;">
                <span>⚠️⚠️⚠️⚠️⚠️</span>
            </dd>
        </summary>
        <div>
            <div>
                <input type="radio" name="mode_of_extension_1rst" id="automatic_detec_setup" value="automatic" checked>
                <label for="automatic_detec_setup">Automatic</label>

                <input type="radio" name="mode_of_extension_1rst" id="manual_detec_setup" value="manual">
                <label for="manual_detec_setup">Manual</label>

            </div>
            <fieldset id="dahsboard_automatic_only_lol">
                <span id="msg_for_user_1rst">
                    ✅ All good!<br>
                    Waiting for you to start the activity.
                </span>
            </fieldset>
            <fieldset id="dahsboard_manual_only_lol">
                <section>
                    <dd>Disable all</dd>
                    <dd data-values1rst="true1">true</dd>
                </section>
                <section>
                    <dd>Sensor off</dd>
                    <dd data-values1rst="false2">false</dd>
                    <dd data-values1rst="true2">true</dd>
                </section>
                <section>
                    <dd>Copy-paste</dd>
                    <dd data-values1rst="false3">false</dd>
                    <dd data-values1rst="true3">true</dd>
                </section>
                <section>
                    <dd>Detected count</dd>
                    <dd data-values1rst="check4">check</dd>
                    <dd>0</dd>
                </section>
                <dd>
                    <span id="msg_for_user_2nd">
                        message here for manual
                    </span>
                </dd>
            </fieldset>
        </div>
    </details>
`;

document.body.appendChild(containerelement);

    const draggableCage = document.getElementById('draggableCage');
    let startX, startY, initialX, initialY;

    draggableCage.addEventListener('mousedown', (e) => {
      startX = e.clientX;
      startY = e.clientY;
      initialX = draggableCage.offsetLeft;
      initialY = draggableCage.offsetTop;
      document.addEventListener('mousemove', drag);
      document.addEventListener('mouseup', stopDrag);
    });

    function drag(e) {
      const newX = initialX + (e.clientX - startX);
      const newY = initialY + (e.clientY - startY);
      draggableCage.style.top = `${newY}px`;
      draggableCage.style.left = `${newX}px`;
    }
    function stopDrag() {
      document.removeEventListener('mousemove', drag);
      document.removeEventListener('mouseup', stopDrag);
    }

window.addEventListener("keydown", function(e) {
    if (e.altKey && e.key.toLowerCase() === "k") {
        //console.log("Alt + K pressed!");
        const cage = document.getElementById("draggableCage");
        if (cage.style.display === "none" || cage.style.display === "") {
          cage.style.display = "flex";   // show
          cage.style.top = "250px";
          cage.style.left = "750px";
          cage.style.zIndex = "1";
          document.getElementById("draggableCage").open = true;
        } else {
            cage.style.display = "none";   // hide
        }
        e.preventDefault(); 
    }
});

function run_on_loop_lol(){
    //console.log("s");
    try {
          if(do_insert_cheat){
            document.getElementById('warning_detection_1rst').style.display = 'flex'
          }else{
            document.getElementById('warning_detection_1rst').style.display = 'none'
          }
        
            if (document.querySelector('input[name="mode_of_extension_1rst"]:checked').value==="automatic") {
              try {
                let detection_status_1rst=""
                let can_copy_paste_lol_1rst=""
                let cheating_count_1rst="";
                if(do_insert_cheat===true){
                  detection_status_1rst="Detection status: ACTIVE <br> ⚠️Please wait To be turn off⚠️"
                  do_insert_cheat=false;
                  document.getElementById("draggableCage").open = true;
                }else{
                  detection_status_1rst="Detection status: DEACTIVATED <br> ✅ All good ✅"
                }
                if ($._data($('body')[0], 'events') && $._data($('body')[0], 'events').copy) {
                  can_copy_paste_lol_1rst="You can't copy-paste! <br> ⚠️Please wait...⚠️";
                  $('body').off('copy cut paste');
                }else{
                  can_copy_paste_lol_1rst = "You are allowed to copy-paste! <br> ✅Please proceed...✅";
                }
                if(cheating_count > 0){
                  cheating_count_1rst=`⚠️Detected count: ${cheating_count} ⚠️<br> you should just waited`
                }
                document.getElementById('msg_for_user_1rst').innerHTML=
                ` ${detection_status_1rst} <br>
                  ${can_copy_paste_lol_1rst} <br>
                  ${cheating_count_1rst}
                `;
              } catch (err) {
                document.getElementById('msg_for_user_1rst').innerHTML=err + "<br> try the manual"
              }
            }else{
              try {
                let can_copy_paste_2nd=$._data($('body')[0], 'events') && $._data($('body')[0], 'events').copy;
                let msg_for_user_2nd_var="";
                if(do_insert_cheat){
                  extension_manual_1rst_fun(2,1,"red")
                  extension_manual_1rst_fun(2,2,"red")
                  extension_manual_1rst_fun(2,3,"unset")
                  msg_for_user_2nd_var="⚠️Please turn off the sensor⚠️"
                }else{
                  extension_manual_1rst_fun(2,1,"yellowgreen")
                  extension_manual_1rst_fun(2,2,"unset")
                  extension_manual_1rst_fun(2,3,"yellowgreen")
                }
                if(can_copy_paste_2nd){
                  extension_manual_1rst_fun(3,1,"red")
                  extension_manual_1rst_fun(3,2,"red")
                  extension_manual_1rst_fun(3,3,"unset")
                  msg_for_user_2nd_var="⚠️Please turn on copy-paste⚠️"
                }else{
                  extension_manual_1rst_fun(3,1,"yellowgreen")
                  extension_manual_1rst_fun(3,2,"unset")
                  extension_manual_1rst_fun(3,3,"yellowgreen")
                }
                if(do_insert_cheat || can_copy_paste_2nd){
                  extension_manual_1rst_fun(1,1,"red")
                  extension_manual_1rst_fun(1,2,"unset")
                }else{
                  extension_manual_1rst_fun(1,1,"yellowgreen")
                  extension_manual_1rst_fun(1,2,"yellowgreen")
                  msg_for_user_2nd_var="✅ All good ✅"
                }
                if(cheating_count > 0){
                  extension_manual_1rst_fun(4,3,"red")
                }else{
                  extension_manual_1rst_fun(4,3,"yellowgreen")
                }
                document.querySelector(`#dahsboard_manual_only_lol > section:nth-of-type(4) > dd:nth-of-type(3)`).innerHTML=cheating_count
                document.getElementById('msg_for_user_2nd').innerHTML=msg_for_user_2nd_var;
              } catch (err) {
                document.getElementById('msg_for_user_2nd').innerHTML=`${err} <br>Contact the dev`;
              }
          }
        } catch (err) {
        document.getElementById('msg_for_user_2nd').innerHTML=`${err} <br> Contact the dev`;
        document.getElementById('msg_for_user_1rst').innerHTML=`${err} <br> Contact the dev`;
    }
}

function extension_manual_1rst_fun(x,y,z){
    document.querySelector(`#dahsboard_manual_only_lol > section:nth-of-type(${x}) > dd:nth-of-type(${y})`).style.backgroundColor = z;
}

const fieldset_1rst_lol = document.querySelector("#dahsboard_manual_only_lol");

fieldset_1rst_lol.addEventListener("click", function (e) {
    if (e.target && e.target.tagName === "DD" && e.target.hasAttribute("data-values1rst")) {
        const value = e.target.getAttribute("data-values1rst").trim();
         let msg_for_user_2nd_var="";
         try{
              switch(value){
                case "true1":
                  extension_manual_1rst_fun(1,1,"yellowgreen")
                  extension_manual_1rst_fun(1,2,"yellowgreen")
                  extension_manual_1rst_fun(2,1,"yellowgreen")
                  extension_manual_1rst_fun(2,2,"unset")
                  extension_manual_1rst_fun(2,3,"yellowgreen")
                  extension_manual_1rst_fun(3,1,"yellowgreen")
                  extension_manual_1rst_fun(3,2,"unset")
                  extension_manual_1rst_fun(3,3,"yellowgreen")
                  msg_for_user_2nd_var="✅ All good ✅"
                  $(window).off('blur');
                  do_insert_cheat=false;
                  $('body').off('copy cut paste');
                break;
                case "false2":
                  extension_manual_1rst_fun(2,1,"red")
                  extension_manual_1rst_fun(2,2,"red")
                  extension_manual_1rst_fun(2,3,"unset")
                  msg_for_user_2nd_var="⚠️Please turn off the sensor⚠️"
                  do_insert_cheat=true
                break;
                case "true2":
                  extension_manual_1rst_fun(2,1,"yellowgreen")
                  extension_manual_1rst_fun(2,2,"unset")
                  extension_manual_1rst_fun(2,3,"yellowgreen")
                  msg_for_user_2nd_var="✅ All good ✅"
                  do_insert_cheat=false
                break;
                case "false3":
                  extension_manual_1rst_fun(3,1,"red")
                  extension_manual_1rst_fun(3,2,"red")
                  extension_manual_1rst_fun(3,3,"unset")
                  $('body').bind('copy cut paste',function(e) {e.preventDefault(); return false;})
                  msg_for_user_2nd_var="⚠️Please turn on copy-paste⚠️"
                break;
                case "true3":
                  extension_manual_1rst_fun(3,1,"yellowgreen")
                  extension_manual_1rst_fun(3,2,"unset")
                  extension_manual_1rst_fun(3,3,"yellowgreen")
                  $('body').off('copy cut paste');
                  msg_for_user_2nd_var="✅ All good ✅"
                break;
                case "check4":
                  document.querySelector(`#dahsboard_manual_only_lol > section:nth-of-type(4) > dd:nth-of-type(3)`).innerHTML=cheating_count;
                  if(cheating_count > 0){
                    extension_manual_1rst_fun(4,3,"red")
                  }else{
                    extension_manual_1rst_fun(4,3,"yellowgreen")
                  }
                break;     
              }
            document.getElementById('msg_for_user_2nd').innerHTML=msg_for_user_2nd_var;
        } catch (err) {
          document.getElementById('msg_for_user_2nd').innerHTML=`${err} <br> Contact the dev`;
          document.getElementById('msg_for_user_1rst').innerHTML=`${err} <br> Contact the dev`;
        }
    }
});


setInterval(() => run_on_loop_lol(), 1000);